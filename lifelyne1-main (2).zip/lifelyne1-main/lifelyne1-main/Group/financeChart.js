// Savings Goal Chart
const savingsContainer = document.createElement('div');
savingsContainer.id = 'savings-container';
savingsContainer.className = 'transaction-log'; // Use transaction-log styles
savingsContainer.style.marginLeft = '20px'; // Add margin to match the transaction log

const savingsTitle = document.createElement('h2');
savingsTitle.textContent = 'Savings Goal';
savingsTitle.style.borderBottom = '3px solid #000';
savingsTitle.style.paddingBottom = '5px';
savingsContainer.appendChild(savingsTitle);

const savingsInputForm = document.createElement('div');
const goalInput = document.createElement('input');
goalInput.type = 'number';
goalInput.placeholder = 'Savings Goal';
goalInput.style.marginRight = '10px';
const currentSavingsInput = document.createElement('input');
currentSavingsInput.type = 'number';
currentSavingsInput.placeholder = 'Current Savings';
currentSavingsInput.style.marginRight = '10px';
const updateButton = document.createElement('button');
updateButton.textContent = 'Update Chart';
updateButton.style.padding = '5px 10px';
updateButton.style.backgroundColor = '#4CAF50';
updateButton.style.color = 'white';
updateButton.style.border = 'none';
updateButton.style.borderRadius = '4px';
updateButton.style.cursor = 'pointer';

savingsInputForm.appendChild(goalInput);
savingsInputForm.appendChild(currentSavingsInput);
savingsInputForm.appendChild(updateButton);
savingsContainer.appendChild(savingsInputForm);

const chartCanvas = document.createElement('canvas');
chartCanvas.id = 'savingsChart';
chartCanvas.style.width = '50%'; // Adjust width
chartCanvas.style.height = '25%'; // Adjust height
savingsContainer.appendChild(chartCanvas);

document.body.appendChild(savingsContainer);

let savingsChart;

function updateSavingsChart(goal, current) {
    const ctx = document.getElementById('savingsChart').getContext('2d');

    if (savingsChart) {
        savingsChart.destroy();
    }

    savingsChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Savings'],
            datasets: [
                {
                    label: 'Goal',
                    data: [goal],
                    backgroundColor: 'rgba(54, 162, 235, 0.6)',
                },
                {
                    label: 'Current Savings',
                    data: [current],
                    backgroundColor: 'rgba(75, 192, 192, 0.6)',
                },
            ],
        },
        options: {
            indexAxis: 'y', // Makes the bar chart horizontal
            scales: {
                x: {
                    beginAtZero: true,
                },
            },
        },
    });
}

updateButton.addEventListener('click', function () {
    const goal = parseFloat(goalInput.value);
    const current = parseFloat(currentSavingsInput.value);

    if (isNaN(goal) || isNaN(current)) {
        alert('Please enter valid numbers for both the goal and current savings.');
        return;
    }

    updateSavingsChart(goal, current);
});
