import express from 'express';
import fetch from 'node-fetch';
import GtfsRealtimeBindings from 'gtfs-realtime-bindings';
import cors from 'cors';  // Import CORS

const app = express();
const PORT = 3000;
const API_KEY = process.env.API_KEY || '8e8e7e84662a4cef814140ffc15f3ef5';
const API_URL = 'https://api.nationaltransport.ie/gtfsr/v2/gtfsr';

app.use(cors()); // Use CORS middleware to enable cross-origin requests

// Helper function to convert UNIX epoch to readable time
function convertUnixToReadableTime(unixTime) {
    if (!unixTime) return "unknown";
    const date = new Date(unixTime * 1000); // Convert seconds to milliseconds
    return date.toISOString().slice(0, 19).replace('T', ' '); // Format as "YYYY-MM-DD HH:mm:ss"
}

// Parsing function for GTFS data
function parseGtfsrData(feed) {
    return feed.entity
        .filter(entity => entity.tripUpdate) // Ensure the entity has trip updates
        .map(entity => {
            const trip = entity.tripUpdate.trip;
            const stopTimeUpdates = entity.tripUpdate.stopTimeUpdate.map(stop => {
                const arrivalTime = stop.arrival?.time ? convertUnixToReadableTime(stop.arrival.time) : "unknown";
                const departureTime = stop.departure?.time ? convertUnixToReadableTime(stop.departure.time) : "unknown";

                return {
                    stopSequence: stop.stopSequence,
                    stopId: stop.stopId,
                    arrival: arrivalTime,
                    departure: departureTime,
                    scheduleRelationship: stop.scheduleRelationship || "N/A",
                };
            });

            return {
                tripId: trip.tripId || "N/A",
                routeId: trip.routeId || "N/A",
                startTime: trip.startTime || "N/A",
                startDate: trip.startDate || "N/A",
                directionId: trip.directionId || "N/A",
                stopTimeUpdates: stopTimeUpdates,
            };
        });
}

app.get('/api/gtfsr', async (req, res) => {
    console.log("Fetching GTFS Realtime data...");
    try {
        const response = await fetch(API_URL, {
            method: 'GET',
            headers: {
                'Cache-Control': 'no-cache',
                'x-api-key': API_KEY
            }
        });

        if (!response.ok) {
            const errorText = await response.text();
            console.error(`Failed to fetch data. Status: ${response.status}, Response: ${errorText}`);
            return res.status(response.status).send(`Error: ${errorText}`);
        }

        const buffer = await response.arrayBuffer();
        const feed = GtfsRealtimeBindings.transit_realtime.FeedMessage.decode(
            new Uint8Array(buffer)
        );

        const parsedData = parseGtfsrData(feed);
        console.log("Successfully fetched and parsed GTFS data.");
        res.set('Access-Control-Allow-Origin', '*');
        res.json(parsedData);
    } catch (error) {
        console.error('Error fetching or processing GTFS data:', error);
        res.status(500).send('Internal Server Error');
    }
});

app.listen(PORT, () => {
    console.log(`Proxy server running on http://localhost:${PORT}`);
});
