// Add New Transaction Functionality
const addTransactionButton = document.querySelector('.add-transaction');
const transactionTable = document.querySelector('.transaction-table');

// Create a total balance element
const totalBalanceContainer = document.createElement('div');
totalBalanceContainer.id = 'total-balance';
totalBalanceContainer.style.margin = '10px 0';
totalBalanceContainer.style.fontWeight = 'bold';
totalBalanceContainer.textContent = 'Total Balance: $0.00';
transactionTable.parentElement.insertBefore(totalBalanceContainer, transactionTable);

let totalBalance = 0;

addTransactionButton.addEventListener('click', function () {
    // Create input fields and a submit button dynamically
    const formContainer = document.createElement('div');
    formContainer.id = 'transaction-form-container';
    formContainer.style.marginTop = '10px';

    const nameInput = document.createElement('input');
    nameInput.type = 'text';
    nameInput.placeholder = 'Transaction Name';
    nameInput.style.marginBottom = '5px';
    nameInput.style.display = 'block';
    nameInput.style.width = '100%';

    const amountInput = document.createElement('input');
    amountInput.type = 'number';
    amountInput.placeholder = 'Amount (negative for expense, positive for income)';
    amountInput.style.marginBottom = '5px';
    amountInput.style.display = 'block';
    amountInput.style.width = '100%';

    const submitButton = document.createElement('button');
    submitButton.textContent = 'Add Transaction';
    submitButton.style.padding = '8px 12px';
    submitButton.style.backgroundColor = '#4CAF50';
    submitButton.style.color = 'white';
    submitButton.style.border = 'none';
    submitButton.style.borderRadius = '4px';
    submitButton.style.cursor = 'pointer';

    // Append inputs and button to the form container
    formContainer.appendChild(nameInput);
    formContainer.appendChild(amountInput);
    formContainer.appendChild(submitButton);

    // Append the form container to the transaction log
    addTransactionButton.parentElement.appendChild(formContainer);

    // Handle form submission
    submitButton.addEventListener('click', function () {
        const transactionName = nameInput.value.trim();
        const transactionAmount = parseFloat(amountInput.value);

        if (transactionName && !isNaN(transactionAmount)) {
            // Create a new row with the transaction details
            const newRow = document.createElement('tr');

            const nameCell = document.createElement('td');
            nameCell.textContent = transactionName;

            const amountCell = document.createElement('td');
            amountCell.textContent = `$${transactionAmount.toFixed(2)}`;
            amountCell.style.textAlign = 'right';
            amountCell.style.color = transactionAmount < 0 ? 'red' : 'green';

            const deleteCell = document.createElement('td');
            const deleteButton = document.createElement('button');

            // Create the delete icon
            const deleteIcon = document.createElement('img');
            deleteIcon.src = 'assets/trashIcon.png'; // Make sure this path is correct
            deleteIcon.alt = 'Delete';
            deleteIcon.style.width = '16px';
            deleteIcon.style.height = '16px';

            deleteButton.style.backgroundColor = 'transparent';
            deleteButton.style.border = 'none';
            deleteButton.style.cursor = 'pointer';

            // Append the icon to the button
            deleteButton.appendChild(deleteIcon);

            // Append delete button to delete cell
            deleteCell.appendChild(deleteButton);

            newRow.appendChild(nameCell);
            newRow.appendChild(amountCell);
            newRow.appendChild(deleteCell);

            // Add the new row to the table
            transactionTable.appendChild(newRow);

            // Update total balance
            totalBalance += transactionAmount;
            totalBalanceContainer.textContent = `Total Balance: $${totalBalance.toFixed(2)}`;

            // Add event listener to delete the row
            deleteButton.addEventListener('click', function () {
                newRow.remove();
                totalBalance -= transactionAmount;
                totalBalanceContainer.textContent = `Total Balance: $${totalBalance.toFixed(2)}`;
            });

            // Clear and remove the form
            formContainer.remove();
        } else {
            alert('Please fill out both the transaction name and amount!');
        }
    });

    // Disable the Add New button to prevent duplicate forms
    addTransactionButton.disabled = true;

    // Re-enable the Add New button once the form is submitted or removed
    formContainer.addEventListener('remove', () => {
        addTransactionButton.disabled = false;
    });
});
