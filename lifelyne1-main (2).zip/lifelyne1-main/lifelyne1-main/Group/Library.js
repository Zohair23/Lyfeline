window.onload = loadBooks;

async function loadBooks() {
    try {
        const response = await fetch('/api/books');
        const books = await response.json();
        console.log('Books loaded:', books); // Debug log
        displayBooks(books);
    } catch (err) {
        console.error('Error loading books:', err);
    }
}

function displayBooks(books) {
    const bookList = document.getElementById('book-list');
    bookList.innerHTML = '';

    books.forEach(book => {
        const li = document.createElement('li');
        li.className = 'book-item';
        li.setAttribute('data-status', book.status.toLowerCase());
        li.setAttribute('data-bookmarked', book.bookmark);

        li.innerHTML = `
            <select class="status-dropdown" data-book-id="${book.id}">
                <option value="awaiting" ${book.status === 'Awaiting' ? 'selected' : ''}>Awaiting</option>
                <option value="reading" ${book.status === 'Reading' ? 'selected' : ''}>Reading</option>
                <option value="read" ${book.status === 'Read' ? 'selected' : ''}>Read</option>
            </select>
            <span class="book-name">${book.title} - ${book.author}</span>
            <i class="${book.bookmark ? 'fas' : 'far'} fa-star bookmark-icon" onclick="toggleBookmark(this, ${book.id})"></i>
        `;
        
        bookList.appendChild(li);
    });
}

async function toggleBookmark(icon, bookId) {
    const isBookmarked = icon.classList.contains('fas');
    const newBookmarkStatus = !isBookmarked;

    try {
        const response = await fetch('/api/books/bookmark', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: bookId, bookmark: newBookmarkStatus })
        });
        
        if (!response.ok) throw new Error('Failed to update bookmark');
        
        const result = await response.json();
        if (result.success) {
            icon.classList.toggle('fas');
            icon.classList.toggle('far');
            icon.closest('.book-item').setAttribute('data-bookmarked', newBookmarkStatus);
        }
    } catch (err) {
        console.error('Error updating bookmark:', err);
    }
}

function filterBooks() {
    const filterValue = document.getElementById("filter-dropdown").value;
    const bookItems = document.querySelectorAll(".book-item");

    bookItems.forEach(item => {
        const status = item.getAttribute("data-status");
        const bookmarked = item.getAttribute("data-bookmarked") === 'true';
        if (filterValue === "" || status === filterValue || (filterValue === "bookmarked" && bookmarked)) {
            item.style.display = ""; 
        } else {
            item.style.display = "none"; 
        }
    });
}

function searchBooks() {
    const searchValue = document.getElementById("search-bar").value.toLowerCase();
    const bookItems = document.querySelectorAll(".book-item");

    bookItems.forEach(item => {
        const bookName = item.querySelector(".book-name").textContent.toLowerCase();
        item.style.display = bookName.includes(searchValue) ? "" : "none";
    });
}

function navigateTo(url) {
    window.location.href = url;
}