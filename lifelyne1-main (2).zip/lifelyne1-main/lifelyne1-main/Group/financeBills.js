// Add New Bill Functionality with Delete Option
const addBillButton = document.querySelector('.finance-box .add-new');
const billsTable = document.querySelector('.finance-box .finance-table');

addBillButton.addEventListener('click', function () {
    // Create input fields and a submit button dynamically
    const formContainer = document.createElement('div');
    formContainer.id = 'bill-form-container';
    formContainer.style.marginTop = '10px';

    const nameInput = document.createElement('input');
    nameInput.type = 'text';
    nameInput.placeholder = 'Bill Name';
    nameInput.style.marginBottom = '5px';
    nameInput.style.display = 'block';
    nameInput.style.width = '100%';

    const dateInput = document.createElement('input');
    dateInput.type = 'date';
    dateInput.style.marginBottom = '5px';
    dateInput.style.display = 'block';
    dateInput.style.width = '100%';

    const submitButton = document.createElement('button');
    submitButton.textContent = 'Add Bill';
    submitButton.style.padding = '8px 12px';
    submitButton.style.backgroundColor = '#4CAF50';
    submitButton.style.color = 'white';
    submitButton.style.border = 'none';
    submitButton.style.borderRadius = '4px';
    submitButton.style.cursor = 'pointer';

    // Append inputs and button to the form container
    formContainer.appendChild(nameInput);
    formContainer.appendChild(dateInput);
    formContainer.appendChild(submitButton);

    // Append the form container to the finance box
    addBillButton.parentElement.appendChild(formContainer);

    // Handle form submission
    submitButton.addEventListener('click', function () {
        const billName = nameInput.value.trim();
        const billDate = dateInput.value;

        if (billName && billDate) {
            // Create a new row with the bill details
            const newRow = document.createElement('tr');

            const dateCell = document.createElement('td');
            dateCell.textContent = new Date(billDate).toLocaleDateString();

            const nameCell = document.createElement('td');
            nameCell.textContent = billName;

            const deleteCell = document.createElement('td');
            const deleteButton = document.createElement('button');

            // Create the delete icon
            const deleteIcon = document.createElement('img');
            deleteIcon.src = 'assets/trashIcon.png'; // Make sure this path is correct
            deleteIcon.alt = 'Delete';
            deleteIcon.style.width = '16px';
            deleteIcon.style.height = '16px';

            deleteButton.style.backgroundColor = 'transparent';
            deleteButton.style.border = 'none';
            deleteButton.style.cursor = 'pointer';

            // Append the icon to the button
            deleteButton.appendChild(deleteIcon);

            // Append delete button to delete cell
            deleteCell.appendChild(deleteButton);

            newRow.appendChild(dateCell);
            newRow.appendChild(nameCell);
            newRow.appendChild(deleteCell);

            // Add the new row to the table
            billsTable.appendChild(newRow);

            // Add event listener to delete the row
            deleteButton.addEventListener('click', function () {
                newRow.remove();
            });

            // Clear and remove the form
            formContainer.remove();
        } else {
            alert('Please fill out both the bill name and date!');
        }
    });

    // Disable the Add New button to prevent duplicate forms
    addBillButton.disabled = true;

    // Re-enable the Add New button once the form is submitted or removed
    formContainer.addEventListener('remove', () => {
        addBillButton.disabled = false;
    });
});
