let timer;
let timeLeft = 25 * 60; // Start with 25 minutes in seconds
let isRunning = false;

// Update the timer display
function updateDisplay() {
    const minutes = Math.floor(timeLeft / 60).toString().padStart(2, '0');
    const seconds = (timeLeft % 60).toString().padStart(2, '0');
    document.getElementById('time').innerText = `${minutes}:${seconds}`;
}

// Start or pause the timer
document.getElementById('startButton').addEventListener('click', function() {
    if (isRunning) {
        clearInterval(timer);
        isRunning = false;
        this.innerText = 'START';
    } else {
        timer = setInterval(() => {
            if (timeLeft > 0) {
                timeLeft--;
                updateDisplay();
            } else {
                clearInterval(timer);
                isRunning = false;
                document.getElementById('startButton').innerText = 'START';
                alert('Time is up!');
            }
        }, 1000);
        isRunning = true;
        this.innerText = 'PAUSE';
    }
});

// Set Pomodoro time (25 minutes)
function setPomodoro() {
    clearInterval(timer);
    timeLeft = 25 * 60;
    isRunning = false;
    updateDisplay();
    document.getElementById('startButton').innerText = 'START';
}

// Set Short Break time (5 minutes)
function setShortBreak() {
    clearInterval(timer);
    timeLeft = 5 * 60;
    isRunning = false;
    updateDisplay();
    document.getElementById('startButton').innerText = 'START';
}

// Set Long Break time (15 minutes)
function setLongBreak() {
    clearInterval(timer);
    timeLeft = 15 * 60;
    isRunning = false;
    updateDisplay();
    document.getElementById('startButton').innerText = 'START';
}

// Initialize display
updateDisplay();