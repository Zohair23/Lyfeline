Hi, in order to run the application, make sure node js is installed on your PC, then run 'npm install', to install any dependencies (node modules folder), then run 'node Mainserver.js', to navigate, go to: http://localhost:3000.
 
Database:
To access the database create a new database using pgadmin called "Lyfeline_db".
details:
host: 'localhost'
database: 'Lyfeline_db'
user: 'postgres' (default)
password: 'Group17'
port: 5432 (default)

The code should connect the database if you input the exact same information.

Bus Scedule (instructioins)
If running in vscode, open the vscode developer command prompt and change the directory to where the project files are stored.
Once in project directory, type "node server.js" and the server should be running on port 3000.
Go to browser and type in localhost:3000/api/gtfsr.
Return to trasport html page and after a short while the TFI bus schedule will appear.

