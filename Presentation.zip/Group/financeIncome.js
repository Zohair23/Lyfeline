// Function to calculate the previous Monday's date
function getPreviousMonday(date) {
    const day = date.getDay();
    const diff = date.getDate() - day + (day === 0 ? -6 : 1);
    return new Date(date.setDate(diff));
}

// Set the current week's starting date in the page
const today = new Date();
const previousMonday = getPreviousMonday(new Date(today));
document.getElementById('current-date').textContent = previousMonday.toLocaleDateString();

// Add New Income Functionality with Delete Option
const addIncomeButton = document.querySelectorAll('.finance-box .add-new')[1];
const incomeTable = document.querySelectorAll('.finance-box .finance-table')[1];

addIncomeButton.addEventListener('click', function () {
    // Create input fields and a submit button dynamically
    const formContainer = document.createElement('div');
    formContainer.id = 'income-form-container';
    formContainer.style.marginTop = '10px';

    const nameInput = document.createElement('input');
    nameInput.type = 'text';
    nameInput.placeholder = 'Income Name';
    nameInput.style.marginBottom = '5px';
    nameInput.style.display = 'block';
    nameInput.style.width = '100%';

    const dateInput = document.createElement('input');
    dateInput.type = 'date';
    dateInput.style.marginBottom = '5px';
    dateInput.style.display = 'block';
    dateInput.style.width = '100%';

    const submitButton = document.createElement('button');
    submitButton.textContent = 'Add Income';
    submitButton.style.padding = '8px 12px';
    submitButton.style.backgroundColor = '#4CAF50';
    submitButton.style.color = 'white';
    submitButton.style.border = 'none';
    submitButton.style.borderRadius = '4px';
    submitButton.style.cursor = 'pointer';

    // Append inputs and button to the form container
    formContainer.appendChild(nameInput);
    formContainer.appendChild(dateInput);
    formContainer.appendChild(submitButton);

    // Append the form container to the income box
    addIncomeButton.parentElement.appendChild(formContainer);

    // Handle form submission
    submitButton.addEventListener('click', function () {
        const incomeName = nameInput.value.trim();
        const incomeDate = dateInput.value;

        if (incomeName && incomeDate) {
            // Create a new row with the income details
            const newRow = document.createElement('tr');

            const dateCell = document.createElement('td');
            dateCell.textContent = new Date(incomeDate).toLocaleDateString();

            const nameCell = document.createElement('td');
            nameCell.textContent = incomeName;

            const deleteCell = document.createElement('td');
            const deleteButton = document.createElement('button');

            // Create the delete icon
            const deleteIcon = document.createElement('img');
            deleteIcon.src = 'assets/trashIcon.png'; // Make sure this path is correct
            deleteIcon.alt = 'Delete';
            deleteIcon.style.width = '16px';
            deleteIcon.style.height = '16px';

            deleteButton.style.backgroundColor = 'transparent';
            deleteButton.style.border = 'none';
            deleteButton.style.cursor = 'pointer';

            // Append the icon to the button
            deleteButton.appendChild(deleteIcon);

            // Append delete button to delete cell
            deleteCell.appendChild(deleteButton);

            newRow.appendChild(dateCell);
            newRow.appendChild(nameCell);
            newRow.appendChild(deleteCell);

            // Add the new row to the table
            incomeTable.appendChild(newRow);

            // Add event listener to delete the row
            deleteButton.addEventListener('click', function () {
                newRow.remove();
            });

            // Clear and remove the form
            formContainer.remove();
        } else {
            alert('Please fill out both the income name and date!');
        }
    });

    // Disable the Add New button to prevent duplicate forms
    addIncomeButton.disabled = true;

    // Re-enable the Add New button once the form is submitted or removed
    formContainer.addEventListener('remove', () => {
        addIncomeButton.disabled = false;
    });
});
