const quotes = [
    "Believe you can and you're halfway there. – Theodore Roosevelt",
    "Success is not final, failure is not fatal: It is the courage to continue that counts. – Winston Churchill",
    "Don't watch the clock; do what it does. Keep going. – Sam Levenson",
    "The only way to do great work is to love what you do. – Steve Jobs",
    "The harder you work for something, the greater you'll feel when you achieve it.",
    "Success usually comes to those who are too busy to be looking for it. – Henry David Thoreau",
    "Don't stop when you're tired. Stop when you're done.",
    "The future depends on what you do today. – Mahatma Gandhi"
 ];
 
 
 // Function to get a quote based on the current date
 function getDailyQuote() {
    const date = new Date();
    const quoteIndex = date.getDate() % quotes.length;
    return quotes[quoteIndex];
 }
 
 
 // Display the quote
 const quoteText = document.getElementById('quoteText');
 quoteText.innerText = getDailyQuote();
 