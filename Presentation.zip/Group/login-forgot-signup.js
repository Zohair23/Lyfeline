function validateForm(event) {
    event.preventDefault();

    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value.trim();

    if (email === '' || password === '') {
        alert('Please fill in all fields');
        return false;
    }

    // Placeholder for real authentication
    alert('Login successful! Welcome back :)');

    // Redirect to the main page (HomePage)
    window.location.href = 'HomePage.html'; 
    return true;
}

function handlePasswordReset(event) {
    event.preventDefault();
    const email = document.getElementById('reset-email').value.trim();

    if (email === '') {
        alert('Please enter your email');
        return false;
    }

    // Placeholder for actual password reset functionality
    alert(`Password reset link sent to ${email}!`);
    return true;
}

function validatePassword() {
    const password = document.getElementById('password').value;
    const passwordHint = document.getElementById('password-hint');
    
    // Define the password requirements
    const minLength = /.{8,}/;
    const hasUppercase = /[A-Z]/;
    const hasLowercase = /[a-z]/;
    const hasDigit = /\d/;
    const hasSpecialChar = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]+/;
    
    // Check if the password meets all requirements
    const isValid = minLength.test(password) &&
                    hasUppercase.test(password) &&
                    hasLowercase.test(password) &&
                    hasDigit.test(password) &&
                    hasSpecialChar.test(password);

    if (isValid) {
        passwordHint.textContent = "Password is strong!";
        passwordHint.classList.remove('invalid');
        passwordHint.classList.add('valid');
    } else {
        passwordHint.textContent = "Password must be at least 8 characters, include uppercase, lowercase, a digit, and a special character.";
        passwordHint.classList.remove('valid');
        passwordHint.classList.add('invalid');
    }
}

function handleSignUp(event) {
    event.preventDefault();

    const fullName = document.getElementById('full-name').value.trim();
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirm-password').value;

    // Check if passwords match
    if (password !== confirmPassword) {
        alert("Passwords do not match!");
        return false;
    }

    // Check if the password meets the requirements
    const passwordHint = document.getElementById('password-hint');
    if (passwordHint.classList.contains('invalid')) {
        alert("Please enter a valid password.");
        return false;
    }

    alert(`Account created successfully for ${fullName}!`);

     // Redirect to the main page (HomePage)
     window.location.href = 'HomePage.html'; 
    return true;
}
