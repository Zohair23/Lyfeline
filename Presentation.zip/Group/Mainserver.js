const express = require('express');
const { Client } = require('pg');
const path = require('path');

const app = express();
app.use(express.json());
app.use(express.static(__dirname));

const client = new Client({
    host: 'localhost',
    database: 'Lyfeline_db',
    user: 'postgres',
    password: 'Group17',
    port: 5432,
});

client.connect(err => {
    if (err) {
        console.error('Connection error', err.stack);
    } else {
        console.log('Connected to database');
    }
});

// Serve HomePage.html as the default page
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, './HomePage.html'));
});

// Serve Library.html for /Library route
app.get('/library', (req, res) => {
    res.sendFile(path.join(__dirname, './library.html'));
});

// Serve studypage.html for /studypage route
app.get('/studypage', (req, res) => {
    res.sendFile(path.join(__dirname, './studypage.html'));
});

// Serve finance.html for /finance route
app.get('/finance', (req, res) => {
    res.sendFile(path.join(__dirname, './finance.html'));
});

// Serve todolist.html for /todolist route
app.get('/todolist', (req, res) => {
    res.sendFile(path.join(__dirname, './todolist.html'));
});

// Serve pomodoro.html for /pomodoro route
app.get('/pomodoro', (req, res) => {
    res.sendFile(path.join(__dirname, './pomodoro.html'));
});

// Serve quotes.html for /quotes route
app.get('/quotes', (req, res) => {
    res.sendFile(path.join(__dirname, './quotes.html'));
});

// API endpoint to get books from database
app.get('/api/books', (req, res) => {
    client.query('SELECT * FROM books ORDER BY id', (err, result) => {
        if (err) {
            console.error('Error fetching books:', err);
            res.status(500).send('Error fetching books');
        } else {
            res.json(result.rows);
        }
    });
});

// API endpoint to update bookmark status
app.post('/api/books/bookmark', (req, res) => {
    const { id, bookmark } = req.body;
    client.query('UPDATE books SET bookmark = $1 WHERE id = $2', [bookmark, id], (err, result) => {
        if (err) {
            console.error('Error updating bookmark:', err);
            res.status(500).send('Error updating bookmark');
        } else {
            res.json({ success: true });
        }
    });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});